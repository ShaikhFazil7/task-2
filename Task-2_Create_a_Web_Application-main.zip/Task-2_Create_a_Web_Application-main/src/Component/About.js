import React from 'react'
import './Style.css'

const About = () => {
    return (
        <div>
            <div className='about'>
                <h1>About</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, dignissimos facilis ea atque voluptatibus nobis animi molestiae quod Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, dignissimos facilis ea atque voluptatibus nobis animi molestiae quod.Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, dignissimos facilis ea atque voluptatibus nobis animi molestiae quod? <br/><br/>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, dignissimos facilis ea atque voluptatibus nobis animi molestiae quod.
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, dignissimos facilis ea atque voluptatibus nobis animi molestiae quod
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, dignissimos facilis ea atque voluptatibus nobis animi molestiae quod? <br/>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, dignissimos facilis ea atque voluptatibus nobis animi molestiae quod Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, dignissimos facilis ea atque voluptatibus nobis animi molestiae quod.Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, dignissimos facilis ea atque voluptatibus nobis animi molestiae quod? <br/><br/>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, dignissimos facilis ea atque voluptatibus nobis animi molestiae quod.
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla doloribus, veniam pariatur quae dolorem, facere unde necessitatibus et aperiam dolor illo, </p>
                
            </div>
        </div>
    )
}

export default About;
